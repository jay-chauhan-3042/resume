<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\VoteController;
use Illuminate\Support\Facades\Route;


Route::get('/', [VoteController::class, 'showForm'])->name('vote.form');
Route::post('/voting', [VoteController::class, 'submitForm'])->name('vote.submit');
Route::post('/send-otp', [VoteController::class, 'sendOtp'])->name('send.otp');
Route::get('/admin/vote-report', [AdminController::class, 'voteReport'])->middleware('admin');
