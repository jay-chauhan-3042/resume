<!DOCTYPE html>
<html>
<head>
    <title>Vote Report</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 800px;
            width: 100%;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Vote Report</h1>
        <table>
            <thead>
                <tr>
                    <th>Person Name</th>
                    <th>Yes Votes</th>
                    <th>No Votes</th>
                    <th>Total Votes</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($persons as $person)
                    <tr>
                        <td>{{ $person->name }}</td>
                        <td>{{ $person->votes->where('vote_type', 'yes')->count() }}</td>
                        <td>{{ $person->votes->where('vote_type', 'no')->count() }}</td>
                        <td>{{ $person->votes_count }}</td> <!-- Display total votes count from the attribute -->
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</body>
</html>
