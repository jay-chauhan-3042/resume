<?php

namespace Database\Factories;

use App\Models\Person;
use Illuminate\Database\Eloquent\Factories\Factory;
use Faker\Generator as Faker;

class PersonFactory extends Factory
{
    protected $model = Person::class;

    public function definition()
    {
        return [
            'name' => $this->faker->name,
            'image_path' => $this->faker->imageUrl(100, 100, 'people'), // Dummy image URL
            'vote_options' => $this->faker->randomElement(['yes_no', 'either']),
        ];
    }
}
