<?php

namespace Database\Factories;

use App\Models\Vote;
use App\Models\Person;
use Illuminate\Database\Eloquent\Factories\Factory;
use Faker\Generator as Faker;

class VoteFactory extends Factory
{
    protected $model = Vote::class;

    public function definition()
    {
        return [
            'person_id' => Person::factory(), // Associate with a Person
            'vote_type' => $this->faker->randomElement(['yes', 'no']),
            'full_name' => $this->faker->name,
            'email' => $this->faker->safeEmail,
            'phone_number' => $this->faker->phoneNumber,
            'member_id' => $this->faker->unique()->numerify('ID###'),
            'otp' => $this->faker->randomNumber(6),
        ];
    }
}

