<?php

namespace Database\Seeders;

use App\Models\Person;
use App\Models\User;
use App\Models\Vote;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]);
        // Seed the people table
        Person::factory()->count(4)->create();

        // Seed the votes table with random votes
        Vote::factory()->count(20)->create();
    }
}
