<?php Basset::basset(base_path('vendor/backpack/theme-tabler/resources/assets/js/tabler.js')); ?>
<?php Basset::basset('https://unpkg.com/@tabler/core@1.0.0-beta19/dist/js/tabler.min.js'); ?>
<?php /**PATH /Users/dj_jay/Desktop/Laravel Projects/voting-app/vendor/backpack/theme-tabler/resources/views/inc/theme_scripts.blade.php ENDPATH**/ ?>