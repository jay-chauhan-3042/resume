<!DOCTYPE html>
<html>
<head>
    <title>Voting Form</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            max-width: 1000px;
            width: 100%;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .people-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }
        .people-grid div {
            text-align: center;
            background: #f9f9f9;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        .people-grid img {
            width: 100px;
            height: auto;
            border-radius: 4px;
            margin-bottom: 10px;
        }
        .form-group input[type="text"],
        .form-group input[type="email"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            margin-bottom: 10px;
        }
        .form-group input[type="text"]:required,
        .form-group input[type="email"]:required {
            background-color: #e9ecef;
        }
        .form-group input[type="submit"],
        .form-group button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }
        .form-group button:hover,
        .form-group input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .form-group .otp-field {
            display: none;
        }
        .form-group label {
            display: block;
            margin: 5px 0;
        }
        .spinner {
            border: 2px solid rgba(0, 0, 0, 0.1);
            border-radius: 50%;
            border-top: 2px solid #fff;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            margin-right: 10px;
            display: inline-block;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .button-disabled {
            background-color: #b0bec5;
            cursor: not-allowed;
        }
        .button-disabled .spinner {
            border-top-color: rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Voting Form</h1>
        <form id="voteForm" action="<?php echo e(url('/voting')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="people-grid">
                <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <img src="<?php echo e($person->image_path); ?>" alt="<?php echo e($person->name); ?>">
                        <p><?php echo e($person->name); ?></p>
                        <?php if($person->vote_options === 'yes_no'): ?>
                            <label>
                                <input type="radio" name="vote_type_<?php echo e($person->id); ?>" value="yes" required> Yes
                            </label>
                            <label>
                                <input type="radio" name="vote_type_<?php echo e($person->id); ?>" value="no" required> No
                            </label>
                        <?php else: ?>
                            <label>
                                <input type="radio" name="vote_type" value="<?php echo e($person->id); ?>" required> Vote for <?php echo e($person->name); ?>

                            </label>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="form-group">
                <input type="text" name="full_name" placeholder="Full Name" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            <div class="form-group">
                <input type="text" name="phone_number" placeholder="Phone Number" required>
            </div>
            <div class="form-group">
                <input type="text" name="member_id" placeholder="Member ID" required>
            </div>

            <div class="form-group">
                <button type="button" id="sendOtpBtn">Send OTP <span class="spinner" id="spinner" style="display: none;"></span></button>
            </div>
            <div class="form-group otp-field" id="otp-section" style="display: none;">
                <input type="text" name="otp" placeholder="Enter OTP" id="otp-field" required>
            </div>
            <div class="form-group">
                <input type="submit" id="submitBtn" value="Submit" style="display: none;">
            </div>
        </form>
    </div>

    <script>
        $(document).ready(function() {
            var otp = "";

            $('#sendOtpBtn').click(function() {
                const email = $('input[name="email"]').val();
                const csrfToken = $('meta[name="csrf-token"]').attr('content');

                // Disable the button and show spinner
                $(this).addClass('button-disabled');
                $('#spinner').show();

                $.ajax({
                    url: '/send-otp',
                    type: 'POST',
                    data: {
                        email: email,
                        _token: csrfToken
                    },
                    success: function(data) {
                        $('#otp-section').show(); // Show the OTP input field
                        otp = data.otp;
                        $('#sendOtpBtn').removeClass('button-disabled');
                        $('#spinner').hide();
                        $('#submitBtn').show(); // Show the submit button
                        toastr.success('OTP sent successfully.');
                    },
                    error: function(xhr) {
                        console.error('Error:', xhr.responseText);
                        $('#sendOtpBtn').removeClass('button-disabled');
                        $('#spinner').hide();
                        toastr.error('Failed to send OTP. Please try again.');
                    }
                });
            });

            $('#voteForm').submit(function(event) {
                event.preventDefault();

                let enteredOtp = $("#otp-field").val();

                if (otp !== enteredOtp) {
                    toastr.error('Invalid OTP. Please try again.');
                    return false;
                } else {
                    const formData = $(this).serialize();
                    const csrfToken = $('meta[name="csrf-token"]').attr('content');

                    $.ajax({
                        url: $(this).attr('action'),
                        type: 'POST',
                        data: formData,
                        headers: {
                            'X-CSRF-TOKEN': csrfToken
                        },
                        success: function(response) {
                            toastr.success('Vote submitted successfully!');
                            $('#voteForm')[0].reset();
                            $('#otp-section').hide();
                            $('#submitBtn').hide(); // Hide the submit button again
                        },
                        error: function(xhr) {
                            console.error('Error:', xhr.responseText);
                            toastr.error('Failed to submit vote. Please try again.');
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
<?php /**PATH /Users/dj_jay/Desktop/Laravel Projects/voting-app/resources/views/vote_form.blade.php ENDPATH**/ ?>