<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Person;

class AdminController extends Controller
{
    public function voteReport()
    {
        $persons = Person::withCount('votes')->get();
        return view('admin.vote_report', compact('persons'));
    }
}
