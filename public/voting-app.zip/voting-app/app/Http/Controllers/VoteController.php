<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Person;
use App\Models\Vote;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class VoteController extends Controller
{
    public function showForm()
    {
        $persons = Person::all();
        return view('vote_form', compact('persons'));
    }

    public function submitForm(Request $request)
    {
        $request->validate([
            'full_name' => 'required|string|max:255',
            'email' => 'required|email',
            'phone_number' => 'required|string|max:15',
            'member_id' => 'required|string|max:255',
            'otp' => 'required|string|min:6|max:8',
        ]);

        // Handle form data
        $votes = $request->except(['_token', 'full_name', 'email', 'phone_number', 'member_id', 'otp']);

        foreach ($votes as $key => $vote) {
            if (str_starts_with($key, 'vote_type_')) {
                $personId = str_replace('vote_type_', '', $key);
                
                // Validate vote type based on the person and expected values
                if (in_array($vote, ['yes', 'no'])) {
                    Vote::create([
                        'person_id' => (int) $personId,
                        'vote_type' => $vote,
                        'full_name' => $request->full_name,
                        'email' => $request->email,
                        'phone_number' => $request->phone_number,
                        'member_id' => $request->member_id,
                    ]);
                }
            } else if ($key === 'vote_type') {
                Vote::create([
                    'person_id' => (int) $vote,
                    'vote_type' => 'either', // Assuming 'either' for single choice selection
                    'full_name' => $request->full_name,
                    'email' => $request->email,
                    'phone_number' => $request->phone_number,
                    'member_id' => $request->member_id,
                ]);
            }
        }

        return redirect()->back()->with('success', 'Vote submitted successfully!');
    }

    public function sendOtp(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $otp = Str::random(6); // Generate a random OTP

        // Send OTP email
        Mail::raw("Your OTP is: $otp", function($message) use ($request, $otp) {
            $message->to($request->input('email'))
                    ->subject('Your OTP Code');
        });

        return response()->json(['otp' => $otp]);
    }
}
