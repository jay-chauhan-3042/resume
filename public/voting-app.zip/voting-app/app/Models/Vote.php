<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Vote extends Model
{
    use HasFactory;

    protected $fillable = [
        'person_id', 'vote_type', 'full_name', 'email', 'phone_number', 'member_id', 'otp'
    ];

    public function person()
    {
        return $this->belongsTo(Person::class);
    }
}